create database Clinica;

use Clinica;

create table Ambulatorios (
nroa int not null,
andar numeric(3) not null,
capacidade smallint null,

primary key (nroa) 
);

insert into Ambulatorios (andar,capacidade) values (1,'30');
insert into Ambulatorios (andar,capacidade) values (1,'50');
insert into Ambulatorios (andar,capacidade) values (2,'40');
insert into Ambulatorios (andar,capacidade) values (2,'25');
insert into Ambulatorios (andar,capacidade) values (2,'55');

create table Medicos (
codm int not null auto_increment,
nome varchar(40) not null,
idade numeric(9,2) not null,codf
especialidade char(20) null,
CPF numeric(11) unique key not null,
cidade varchar(30) null,
nroa int null,

primary key (codm)
);

insert into Medicos (nome,idade,especialidade,CPF,cidade,nroa) values ('Joao',40,'ortopedia',1000010000,'Florianopolis',1);
insert into Medicos (nome,idade,especialidade,CPF,cidade,nroa) values ('Maria',42,'traumatologia',1000011000,'Blumenau',2);
insert into Medicos (nome,idade,especialidade,CPF,cidade,nroa) values ('Pedro',51,'pediatria',1100010000,'São José',2);
insert into Medicos (nome,idade,especialidade,CPF,cidade,nroa) values ('Carlos',28,'ortopedia',1100011000,'Joinville','');
insert into Medicos (nome,idade,especialidade,CPF,cidade,nroa) values ('Marcia',33,'neurologia',1100011100,'Biguacu',3);

create table Pacientes (
codp int not null auto_increment,
nome varchar(40) not null,
idade smallint not null,
cidade char(30) null,
CPF numeric(11) unique key not null,
doenca varchar(40) not null,

primary key (codp)
);

insert into Pacientes (nome,idade,cidade,CPF,doenca) values ('Ana',20,'Florianopolis',20000200000,'gripe');
insert into Pacientes (nome,idade,cidade,CPF,doenca) values ('Paulo',24,'Palhoca',20000220000,'fratura');
insert into Pacientes (nome,idade,cidade,CPF,doenca) values ('Lucia',30,'Biguacu',22000200000,'tendinite');
insert into Pacientes (nome,idade,cidade,CPF,doenca) values ('Carlos',28,'Joinville',11000110000,'sarampo');


create table Funcionarios (
codf int not null auto_increment,
nome varchar(40) not null,
idade smallint null,
CPF numeric(11) unique key not null,
cidade varchar(30) null,
salario numeric(10) null,
cargo varchar(20) null,

primary key (codf)
);

insert into Funcionarios (nome,idade,cidade,salario,CPF) values ('Rita',32,'Sao Jose',1200,20000100000);
insert into Funcionarios (nome,idade,cidade,salario,CPF) values ('Maria',55,'Palhoca',1220,30000110000);
insert into Funcionarios (nome,idade,cidade,salario,CPF) values ('Caio',45,'Florianopolis',1100,41000100000);
insert into Funcionarios (nome,idade,cidade,salario,CPF) values ('Carlos',44,'Florianopolis',1200,51000110000);
insert into Funcionarios (nome,idade,cidade,salario,CPF) values ('Paula',33,'Florianopolis',2500,61000111000);

create table Consultas (
num_consulta int not null auto_increment,
codm int null,
codp int null,
data date,
hora time null,

primary key (num_consulta)
);

insert into Consultas () 
values (1,1,'2006/06/12','14:00'),
(1,4,'2006/06/12','10:00'),
(2,1,'2006/06/13','09:00'),
(2,2,'2006/06/13','11:00'),
(2,3,'2006/06/13','14:00'),
(2,4,'2006/06/14','17:00'),
(3,1,'2006/06/14','18:00'),
(3,3,'2006/06/19','10:00'),
(3,4,'2006/06/12','13:00'),
(4,4,'2006/06/19','13:00'),
(4,4,'2006/06/20','19:30');





ALTER TABLE Funcionarios ADD nroa int;

ALTER TABLE Funcionarios DROP COLUMN cargo, DROP COLUMN nroa;










            
